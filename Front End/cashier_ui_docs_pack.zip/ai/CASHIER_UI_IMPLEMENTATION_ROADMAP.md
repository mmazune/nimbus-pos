# CASHIER_UI_IMPLEMENTATION_ROADMAP.md — Nimbus POS Cashier UI Build Roadmap

Status: Draft v1  
Date: 2026-07-01  
Scope: future cashier UI implementation prompts; docs/research complete, implementation pending

## Prompt 0 — Repo/docs/API orientation

Verify docs against live repo before coding. Read cashier docs, waiter docs, schema, seed, demo credentials, API modules, and Postman. Produce `ai/CASHIER_UI_REPO_VERIFICATION_REPORT.md` with exact credentials, permissions, DTOs, endpoints, split tender support, till/refund behavior, and demo fixture readiness. No UI coding.

## Prompt 1 — Cashier shell/design foundation

Implement `CashierShell`, `CashierHeader`, `CashierBottomNav`, readiness chips, route guard, state primitives, caveat banners. Routes: `/cashier/queue`, `/cashier/receipts`, `/cashier/till`, `/cashier/me`.

## Prompt 2 — Auth/session/context routing

Wire Quick PIN and `/api/auth/me`; branch/workspace guard; active shift/till queries; idle logout. Cashier lands on Queue.

## Prompt 3 — Queue/orders

Build Queue screen, order list, search/filter chips, payment/bill state badges, checkout open action, loading/empty/failure/blocked states.

## Prompt 4 — Checkout/payment entry

Build checkout panel, totals/outstanding, payment history, cash tender, card reference, MTN/Airtel provider-gated/manual-reference panels, close order. Use idempotency where supported.

## Prompt 5 — Split bill/items/split tender/advanced resolution

Build split bill, split items, split tender if backend supports multiple payments, merge, move items, transfer table/server. Keep advanced actions out of nav.

## Prompt 6 — Receipts

Build receipt search/list/drawer/history/reprint/send-pending. Enforce metadata-only print and pending send caveats.

## Prompt 7 — Till/safe drop/reconciliation

Build active till summary, open till, safe drop, reconcile, variance state. Cash remains blocked without active till.

## Prompt 8 — Refunds

Build refund drawer with refundable amount, reason, status, previous refunds. Hide approval actions unless permissions prove cashier can approve.

## Prompt 9 — Me tab

Build profile/session/shift/till/self-service/logout. No payroll, staff list, accounting, or reports.

## Prompt 10 — QA/polish/demo readiness

Run cashier login, queue, checkout, payment methods, split, receipt, till, refund, role guard, caveat, and unsupported-action checks. Produce QA report and known limitations.

## Recommended next prompt

```txt
You are working in C:\Users\arman\Desktop\nimbus-pos only.

Do not code UI yet. Verify the Cashier UI docs against live repo source.

Read docs/cashier-ui-docs/*, waiter docs, packages/db/prisma/schema.prisma, packages/db/prisma/seed.ts, packages/db/prisma/demo-import.ts, demo-data/DEMO_LOGIN_CREDENTIALS.md, and the API modules for auth, shifts, tills, orders, payments, receipts, refunds, discounts, devices, tables, and reservations.

Produce ai/CASHIER_UI_REPO_VERIFICATION_REPORT.md with:
1. exact Cashier demo credentials/PIN;
2. exact Cashier permissions;
3. exact payment method enum and DTOs;
4. exact endpoint paths and request/response shapes;
5. order queue filter support;
6. split bill/items DTOs;
7. split tender support status;
8. till/cash movement DTOs;
9. refund/discount approval behavior;
10. demo data readiness;
11. updates needed to CASHIER_GAP_REGISTER.md.

Do not modify backend, frontend, Prisma schema, migrations, Postman, or demo database.
```
