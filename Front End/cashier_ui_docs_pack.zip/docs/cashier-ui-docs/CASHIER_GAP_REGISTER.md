# CASHIER_GAP_REGISTER.md — Nimbus POS Cashier UI Gap Register

Status: Draft v1  
Date: 2026-07-01

| ID | Area | Gap | Evidence | Impact | Proposed Action | Status |
|---|---|---|---|---|---|---|
| CASHIER-GAP-001 | Repo verification | Live Windows repo was not mounted here; docs use uploaded resources. | Audit/register files available, source code unavailable. | DTO/path/permission mismatch risk. | Run repo-scoped source verification before coding. | Open |
| CASHIER-GAP-002 | Credentials | Exact cashier demo PIN unknown in mounted resources. | PIN-first support confirmed, demo credential file not mounted. | Login QA risk. | Read `demo-data/DEMO_LOGIN_CREDENTIALS.md`. | Open |
| CASHIER-GAP-003 | Permissions | Exact seeded Cashier permissions need verification. | Audit indicates cashier on receipts/tills/payments/handoff; broad role hints include unrelated accounting rows. | Could expose too much. | Build permission diff from `seed.ts`. | Open |
| CASHIER-GAP-004 | Payment enum | Exact `PaymentMethod`/DTO values unknown. | Audit names cash/card/MTN/manual reference, but enum keys need code. | API payload mismatch. | Verify schema and DTOs. | Open |
| CASHIER-GAP-005 | MTN/Airtel | User wants method assignment, but live execution pending. | Public payments classified scaffold/pending. | Misleading live payment risk. | Provider-gated/manual-reference only. | Locked caveat |
| CASHIER-GAP-006 | PesaPal | Existing PesaPal is SaaS billing only. | Audit says owner SaaS billing. | Wrong diner method risk. | Exclude from cashier. | Locked exclusion |
| CASHIER-GAP-007 | Split tender | Payment summary suggests paid/remaining/isSettled, but multiple tender behavior needs service verification. | Endpoint register lists order payments summary. | UI may overpromise. | Verify tests/service; hide if unsupported. | Open |
| CASHIER-GAP-008 | Split bill DTO | Exact allocation DTO unknown. | BG4.B confirms endpoint, not shape. | Split math mismatch. | Verify DTO before UI. | Open |
| CASHIER-GAP-009 | Split items DTO | Exact item quantity payload unknown. | BG4.B confirms endpoint, not shape. | Bad payload risk. | Verify DTO. | Open |
| CASHIER-GAP-010 | Advanced handoff | Cashier has split/merge/transfer/move permissions, but product is payment-focused. | BG4.B grants Owner/Manager/Cashier. | UI clutter/waiter clone risk. | Put under Advanced checkout resolution only. | Proposed |
| CASHIER-GAP-011 | Bill-requested filter | Need exact order list filter/field. | Waiter docs confirm request bill; endpoint list says filterable. | Queue accuracy risk. | Verify order response/query. | Open |
| CASHIER-GAP-012 | Close rules | Exact close preconditions need verification. | Audit notes pending intent/already-paid tracking. | Close could unlock too early. | Verify service/tests/error codes. | Open |
| CASHIER-GAP-013 | Cash till requirement | Product rule says cash requires active till; code must confirm. | Roadmap/till endpoints support it. | Wrong cash enablement risk. | Verify payment service. | Open |
| CASHIER-GAP-014 | Cash movements | Only safe-drop/reconcile confirmed in uploaded resources. | User asked broader drawer workflow. | Missing pay-in/pay-out/pickup uncertainty. | Search `cash-movements` module in repo. | Open |
| CASHIER-GAP-015 | Refund approval | Cashier create/view likely; approval unclear. | Approvals are manager-facing in audit. | Unauthorized approval risk. | Hide approval unless seed confirms. | Proposed |
| CASHIER-GAP-016 | Discount approval | Request/approve endpoints exist; cashier permission unclear. | Broad audit listings. | Unauthorized discount risk. | Request only if permitted; hide approve unless verified. | Proposed |
| CASHIER-GAP-017 | Receipt printer | No print driver. | Device/printer audit caveat. | Fake print risk. | Metadata-only copy. | Locked caveat |
| CASHIER-GAP-018 | Receipt send | No live adapter. | Receipt audit caveat. | Fake delivery risk. | Pending-only copy. | Locked caveat |
| CASHIER-GAP-019 | Card terminal | Terminal is STUB. | Device audit caveat. | Fake acquirer risk. | Manual reference only. | Locked caveat |
| CASHIER-GAP-020 | Reservation deposits | Deposit endpoints exist but cashier MVP scope unclear. | Reservation routes in register. | Scope creep. | Defer unless approved. | Deferred |
| CASHIER-GAP-021 | Demo fixtures | Need cashier-safe orders/tills/receipts/refunds. | Demo import passes, but cashier fixtures not verified. | Empty demo screens. | Inspect demo data read-only. | Open |
| CASHIER-GAP-022 | Dedicated Postman | Cashier-specific workflow collection not provided. | Waiter has dedicated collection pattern. | QA gap. | Create/verify later if missing. | Open |
| CASHIER-GAP-023 | Path normalization | Both `:id` and `{orderId}` styles appear in audit. | Endpoint CSV normalization. | Wrong client path risk. | Verify controller paths. | Open |
| CASHIER-GAP-024 | Offline recovery | Idempotency exists; frontend recovery design must be implemented. | BG3 reliability. | Double-submit risk. | Status refresh + idempotency recovery. | Open |
