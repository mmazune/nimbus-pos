# CASHIER_API_MATRIX.md — Nimbus POS Cashier API Matrix

Status: Draft v1  
Date: 2026-07-01  
Scope: cashier-relevant endpoint matrix from uploaded audit/register resources. Final coding must verify live controllers, DTOs, permissions, and Postman.

## 1. Rules

- Use existing endpoints only.
- Resolve `:id` vs `{orderId}` canonical paths in source before coding.
- Do not invent routes.
- Add missing/unclear items to `CASHIER_GAP_REGISTER.md`.
- Money/till/refund/close writes should use idempotency where supported.
- Public MTN/Airtel execution, PesaPal diner checkout, real printer, and real terminal traffic are excluded.

## 2. Matrix

| Area | Method | Path | Purpose | UI action | Status/caveat |
|---|---|---|---|---|---|
| Auth | POST | `/api/auth/login` | Email/password login | Shared fallback login | Safe |
| Auth | POST | `/api/auth/quick-pin-login` | PIN login | Cashier Quick PIN | Safe; verify demo PIN |
| Auth | POST | `/api/auth/pin-login` | legacy/email+PIN login | fallback if used | Verify canonical route |
| Auth | GET | `/api/auth/me` | canonical context | Role routing/header context | Required |
| Auth | POST | `/api/auth/logout` | logout | Logout | Safe |
| Shift | GET | `/api/shifts/active` | active shift | readiness chip | Safe |
| Shift | POST | `/api/shifts/open` | open shift | Start shift | Idempotency where supported |
| Shift | POST | `/api/shifts/{shiftId}/close` | close shift | End shift | Verify state blocks |
| Till | GET | `/api/tills/active` | active till | readiness chip/cash gate | Safe |
| Till | POST | `/api/tills/open` | open till | Open till | Idempotency where supported |
| Till | GET | `/api/tills/{tillId}` | till detail | Till screen | Safe |
| Till | GET | `/api/tills/{tillId}/summary` | till summary | expected/count/variance | Safe |
| Till | POST | `/api/tills/{tillId}/safe-drop` | cash safe drop | Record safe drop | Requires active till |
| Till | POST | `/api/tills/{tillId}/reconcile` | reconcile till | Reconcile | Idempotency where supported |
| Orders | GET | `/api/pos/orders` | list orders | Queue | Verify filters/bill state |
| Orders | GET | `/api/pos/orders/{orderId}` | order detail | Checkout | Safe |
| Orders | GET | `/api/pos/orders/{paymentOrderId}/payments` | payment summary | Paid/outstanding/history | Essential for split tender |
| Orders | POST | `/api/pos/orders/:id/close` | close order | Close order | Idempotency; block if unsettled |
| Payments | POST | `/api/payments/intents` | create payment intent | Record payment | Idempotency; no live public MTN/Airtel |
| Payments | GET | `/api/payments/intents/{intentId}` | intent detail | payment detail | Safe |
| Payments | GET | `/api/payments/intents/{intentId}/status` | intent status | refresh pending | Safe |
| Payments | POST | `/api/payments/intents/{intentId}/cancel` | cancel intent | cancel pending | Verify permission |
| Payments | POST | `/api/payments/manual-reference` | manual payment/reference | card/manual MTN/Airtel reference | Safe only as manual reference |
| Payments | GET | `/api/payments/manual-reference` | list references | search/reference review | Verify cashier scope |
| Split | POST | `/api/pos/orders/:id/split-bill` | allocation groups | Split bill | Cashier permitted per audit; verify DTO |
| Split | POST | `/api/pos/orders/:id/split-items` | child order by items | Split items | Verify DTO |
| Handoff | POST | `/api/pos/orders/merge` | merge open orders | Advanced resolution | Confirm impact |
| Handoff | POST | `/api/pos/orders/:id/move-items` | move items | Advanced resolution | Confirm impact |
| Handoff | POST | `/api/pos/orders/:id/transfer-table` | transfer table | Advanced resolution | Not Floor clone |
| Handoff | POST | `/api/pos/orders/:id/transfer-server` | transfer server | Advanced resolution | Not waiter handoff UI |
| Receipts | GET | `/api/receipts/:id` | view receipt | Receipt drawer | Safe |
| Receipts | GET | `/api/receipts/:id/history` | receipt history | History | Safe |
| Receipts | POST | `/api/receipts/:id/reprint` | reprint request | Reprint | Metadata only; no driver |
| Receipts | POST | `/api/receipts/:id/send` | digital send request | Send pending | Pending/no adapter |
| Refunds | GET | `/api/pos/orders/{orderId}/refunds` | list refunds | refund history | Safe if permitted |
| Refunds | POST | `/api/pos/orders/{orderId}/refunds` | create refund | Refund drawer | completed or pending |
| Refunds | POST | `/api/pos/orders/:id/refunds` | BG3 refund write | Refund drawer | Idempotency/training possible |
| Refunds | GET | `/api/pos/refunds/{refundId}` | refund detail | refund detail | Safe if permitted |
| Refunds | POST | `/api/pos/refunds/{refundId}/approve` | approve refund | manager approval | Hide unless cashier permission verified |
| Discounts | GET | `/api/pos/orders/{orderId}/discounts` | list discounts | checkout discount display | Safe if permitted |
| Discounts | POST | `/api/pos/orders/{orderId}/discounts` | request discount | discount request | Do not assume approval |
| Discounts | GET | `/api/pos/discounts/pending` | pending discounts | manager surface | Hide by default |
| Devices | GET | `/api/devices` | device list | terminal/printer metadata | read-only |
| Devices | GET | `/api/devices/printers/routes` | printer routes | caveat/info | metadata only |
| Devices | POST | `/api/devices/terminals/pair` | pair terminal | not cashier write | STUB only; exclude |
| Public payments | any | `/api/public/payments/*` | future public MTN/Airtel | not cashier live checkout | CRITICAL pending provider |
| PesaPal | any | `/api/billing/pesapal/*` | SaaS owner billing | not cashier diner checkout | Exclude |

## 3. Payment method mapping

| UI method | Backend treatment | Demo stance |
|---|---|---|
| Cash | payment endpoint + active till | safe if till open |
| Card | manual reference / stub | safe as reference only |
| MTN | manual reference only if DTO supports | provider-gated |
| Airtel | manual reference only if DTO supports | provider-gated |
| PesaPal | owner SaaS billing only | excluded |

## 4. Explicit exclusions

- Accounting/AP/AR/period/posting/report dashboards.
- KDS state transitions.
- Waiter menu/order item editing.
- Device writes for cashier.
- Live provider/hardware execution.
